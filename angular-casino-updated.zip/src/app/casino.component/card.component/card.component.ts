import { Component, Input } from '@angular/core';
import { Card } from '../card-interface'

@Component({
  selector: 'casino-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})

export class CasinoCard {
  constructor() {   }

  @Input() selectedCard : Card;

}