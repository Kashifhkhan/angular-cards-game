import { Component, Input } from '@angular/core';
import { CardsService } from './cards.service';
import { Card } from './card-interface'

@Component({
  selector: 'casino',
  templateUrl: './casino.component.html',
  styleUrls: ['./casino.component.css']
})

export class Casino {

  @Input() productName: string;
  countdown : number;
  selectedPlayerCardValue : number;
  selectedDealerCardValue : number;
  winnerMsg : string; 
  selectedCard : Card; 
  casinoDeck : Array<any>;
  dealerInt;

  constructor(private cardsService: CardsService) { 
     /*
    Create Deck initial
    */
    this.casinoDeck = this.cardsService.makeDeck();
  }


  /*
  Pick card from Deck combination Array
  @param arg 
  arg - String value Player/Dealer
  */
  selectCard(arg : string) {
      this.cardsService.shuffleDeck(this.casinoDeck);
      
      this.selectedCard = this.casinoDeck.pop();

      // Player/Dealer check
      (arg == 'dealer') ? this.dealerTurn(this.selectedCard) : this.playerTurn(this.selectedCard);

    // conditional check
    if (this.selectedPlayerCardValue > 21) {
      this.winnerMsg = 'Dealer won the game!';
    }
    else if (this.selectedDealerCardValue > 21) {
      this.winnerMsg = 'Player won the game!';
      clearInterval(this.dealerInt);
    }
    else if (this.selectedDealerCardValue >= 17) {
      if (this.selectedDealerCardValue > this.selectedPlayerCardValue) {
        this.winnerMsg = 'Delaer won the game!';
      }
      else if (this.selectedDealerCardValue == this.selectedPlayerCardValue) {
        this.winnerMsg = "It's a Tie!";
      }
      else {
        this.winnerMsg = 'Player won the game!';
      }
      clearInterval(this.dealerInt);
    } 
  }

  // Start Player's Turn 
  getPlayerCard() {
    this.selectCard('player');   
  }

  // Stop Player's Turn & Start Dealer's Turn
  getDealerCard() {
    this.countFunc();
    this.dealerInt = setInterval(() => {
      this.selectCard('dealer');
    }, 3000);
  }

  // Countdown for waiting time 
  countFunc() {
    this.countdown = 3;
    var invt = setInterval(() => {
      (this.countdown == 0) ? clearInterval(invt) : this.countdown--;
    }, 1000);
  }

  // Dealer's card value calculate
  dealerTurn(cardObj) {
    this.selectedDealerCardValue ? this.selectedDealerCardValue += parseInt(cardObj.cardValue)
    : this.selectedDealerCardValue = parseInt(cardObj.cardValue);   
  }

  // Player's card value calculate
  playerTurn(cardObj) {
    this.selectedPlayerCardValue ? this.selectedPlayerCardValue += parseInt(cardObj.cardValue) 
    : this.selectedPlayerCardValue = parseInt(cardObj.cardValue);
  }

  // reset all properties
  restart() {
    delete this.selectedCard;
    this.selectedDealerCardValue = 0;
    this.winnerMsg = '';
    this.selectedPlayerCardValue = 0;
    this.countdown = 0;
    this.casinoDeck = this.cardsService.makeDeck();
  }

}
