import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})

export class CardsService {

  constructor() { }

  /*
  Create Deck combination Array
  */
  makeDeck = () => {
    let arr = [];
    let cardsArray = [{ "Ace": "1" }, { "2": "2" }, { "3": "3" }, { "4": "4" }, { "5": "5" }, { "6": "6" }, { "7": "7" }, { "8": "8" }, { "9": "9" }, { "10": "10" }, { "Jack": "10" }, { "Queen": "10" }, { "King": "10" }];
    let suitsArray = [{ "diamond": "♦" }, { "heart": "♥" }, { "spade": "♠" }, { "club": "♣" }];

    for (let suit in suitsArray) {
      for (let card in cardsArray) {
        arr.push(
          {
            card: Object.keys(cardsArray[card]),
            cardValue: Object["values"](cardsArray[card]),
            type: Object.keys(suitsArray[suit]),
            symbol: Object["values"](suitsArray[suit])
          }
        );
      }
    }
    return arr;
  };

  /*
  Shuffle Deck 
  @param arr 
  arr - array of objects
  */
  shuffleDeck = (arr) => {
    let i, j, temp;
    for (i = 0; i < arr.length; i++) {
      j = Math.floor(Math.random() * arr.length);
      temp = arr[i];
      arr[i] = arr[j];
      arr[j] = temp;
    }
  }
}