export interface Card {  
    card: string,
    cardValue: string,
    type: string,
    symbol: string
}